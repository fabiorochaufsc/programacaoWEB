var MongoClient = require('mongodb').MongoClient
var url = 'mongodb://localhost:27017'


  if (process.argv.length == 5)
  {
    MongoClient.connect(url, function (err, db) {
      if (err) throw err
      var dbo = db.db("APLICACAO");
      let ID       = process.argv[2];
      let nome     = process.argv[3]; 
      let password = process.argv[4]; 
      
      var myobj = { meuID: ID, nome: nome, password: password }
      dbo.collection('Usuarios').insertOne(myobj, function (err, res) {
        if (err)
        {
          console.log("erro inserindo elemento")
        }
        else {
          console.log('1 document inserted')
        }
        db.close()
      })
    })
  }
  else
  {
    console.log("Forma de usar:   insere ID nome senha")
    console.log("Exemplo:         insere frr 'Fabio Rocha' teste123")
  }

